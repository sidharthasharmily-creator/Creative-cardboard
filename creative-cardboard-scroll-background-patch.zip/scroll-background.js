// Creative Cardboard — scrolling background effect
// Add this script near the end of your page, just before </body>.
// It changes ONLY the page background as the visitor scrolls.

(() => {
  const colors = ["#fff7ed", "#fef3c7", "#ecfccb", "#e0f2fe", "#f3e8ff"];
  const update = () => {
    const max = document.documentElement.scrollHeight - window.innerHeight;
    const progress = max > 0 ? window.scrollY / max : 0;
    const index = Math.min(colors.length - 1, Math.floor(progress * colors.length));
    document.body.style.transition = "background-color 500ms ease";
    document.body.style.backgroundColor = colors[index];
  };
  window.addEventListener("scroll", update, { passive: true });
  update();
})();
